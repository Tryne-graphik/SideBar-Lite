// Injecté dans WhatsApp Web (onglet, fenêtre ou cadre du panneau) : envoie au panneau le nombre de discussions non lues,
// lu dans le titre « (3) WhatsApp ». Rien d'autre n'est lu ni envoyé.
const send = () => chrome.runtime.sendMessage({ type: 'wa', n: Number(document.title.match(/^\((\d+)\)/)?.[1] ?? 0) }).catch(() => {})
send()
new MutationObserver(send).observe(document.querySelector('title') ?? document.documentElement, { subtree: true, childList: true, characterData: true })

// Dans le panneau seulement (cadre) : la colonne des conversations est masquée pour laisser toute la place aux messages ;
// la flèche en haut à gauche l'affiche / la cache, et un clic sur une conversation la referme.
if (window !== window.top) {
  const KEY = 'sb-wa-list'
  let open = false
  try { open = localStorage.getItem(KEY) === '1' } catch {}
  const style = document.createElement('style')
  // WhatsApp Web (2026) : colonne des conversations = parent de #side (45 %) ; conteneur de la page = grand-parent, min-width 748 px
  style.textContent = `div:has(> div > #side) { min-width: 0 !important }
    html:not(.sb-list) div:has(> #side) { display: none !important }
    html { --sb-bar: 18px }
    #app { top: var(--sb-bar) !important; height: calc(100% - var(--sb-bar)) !important }
    #sb-toggle { position: fixed; top: 0; left: 0; z-index: 2147483647; width: 64px; height: var(--sb-bar); padding: 0; border: 0; border-radius: 0 0 6px 0;
      background: #00a884; color: #fff; font: 12px/18px sans-serif; cursor: pointer; opacity: .9 }`
  const btn = document.createElement('button')
  btn.id = 'sb-toggle'
  const apply = () => {
    document.documentElement.classList.toggle('sb-list', open)
    btn.textContent = open ? '◀' : '▶'
    btn.title = open ? 'Cacher les conversations' : 'Afficher les conversations'
    try { localStorage.setItem(KEY, open ? '1' : '0') } catch {}
  }
  btn.onclick = () => { open = !open; apply() }
  document.addEventListener('click', e => { // choix d'une conversation : on referme la liste
    if (open && e.target instanceof Element && e.target.closest('#side') && e.target.closest('[role="listitem"], [role="row"]')) setTimeout(() => { open = false; apply() }, 300)
  }, true)
  const mount = () => { document.documentElement.append(style, btn); apply() }
  if (document.documentElement) mount(); else document.addEventListener('DOMContentLoaded', mount)
}
