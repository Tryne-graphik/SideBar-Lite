// Injecté dans Discord quand la page est affichée DANS le panneau SideBar (cadre), jamais dans un onglet normal :
// empile la colonne de gauche (serveurs, salons / messages privés, compte) EN HAUT et le chat EN DESSOUS, pleine largeur,
// pour que tout tienne dans le panneau étroit. Structure relevée le 2026-10-19 : base > content > (sidebar, page).
// Les noms de classes ont un suffixe aléatoire qui change quand Discord se met à jour : on ne cible que la partie fixe ;
// si l'empilement casse un jour, relever la structure à nouveau (voir JOURNAL.md).
const DC_ZOOM = 0.8 // 1 = taille normale ; plus petit = plus de place
const DC_TOP = 42 // % de la hauteur pour la partie haute (serveurs + salons)
if (window !== window.top) {
  const style = document.createElement('style')
  style.textContent = `
    html { zoom: ${DC_ZOOM} !important }
    div[class*="base__"] > div[class*="content__"] { flex-direction: column !important }
    div[class*="base__"] > div[class*="content__"] > [class*="sidebar__"] { flex: none !important; width: 100% !important; height: ${DC_TOP}% !important }
    div[class*="base__"] > div[class*="content__"] > [class*="page__"] { flex: 1 1 0 !important; min-width: 0 !important; min-height: 0 !important; width: 100% !important }`
  document.documentElement.append(style)
}
