const HOST = 'com.tryne.sidebar'
/** @type {(id: string) => any} */
const $ = id => document.getElementById(id)
// chrome.storage renvoie des valeurs non typées : any pour les lire sans transtypage à chaque appel
/** @type {(keys: any) => Promise<any>} */
const getLocal = keys => chrome.storage.local.get(keys)
/** @type {(keys: any) => Promise<any>} */
const getSync = keys => chrome.storage.sync.get(keys)

function host(msg) {
  return chrome.runtime.sendNativeMessage(HOST, msg).then(r => {
    if (r?.error) throw new Error(r.error)
    return r
  })
}

function showError(e) {
  $('err').hidden = false
  $('err').textContent = String(e.message ?? e)
}

function button(label, title, onClick) {
  const b = document.createElement('button')
  b.textContent = label
  b.title = title
  b.onclick = () => Promise.resolve(onClick()).catch(showError)
  return b
}

function row(...children) {
  const li = document.createElement('li')
  li.append(...children)
  return li
}

function span(cls, text) {
  const s = document.createElement('span')
  s.className = cls
  s.textContent = text
  return s
}

function link(text, url, cls = 'name') {
  const a = document.createElement('a')
  a.textContent = text
  a.className = cls
  if (/^https?:\/\//i.test(url)) { a.href = url; a.target = '_blank' }
  return a
}

// Crochet pour rail.js (badges du rail) : l'état est publié à chaque changement (événement 'sbstate', aussi lisible dans window.sbState)
// clés : mail (non lus), wa (discussions non lues), vc (séries à rattraper), tw (chaînes suivies en ligne) ; null = pas encore de données
const sbState = /** @type {any} */ (window).sbState = {}
function publish(key, value) {
  sbState[key] = value
  document.dispatchEvent(new CustomEvent('sbstate', { detail: { ...sbState } }))
}

const when = at => new Date(at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })

// --- Vues : une seule visible, choisie dans le rail ; mémorisée par navigateur (confort seulement)
let ready // résolu quand les projets (menu des dossiers du terminal) sont chargés

function show(view) {
  for (const s of document.querySelectorAll('.view')) s.toggleAttribute('hidden', s.getAttribute('data-view') !== view)
  for (const b of document.querySelectorAll('#rail [data-view]')) b.classList.toggle('on', b.getAttribute('data-view') === view)
  for (const b of document.querySelectorAll('#apps button')) b.classList.remove('on')
  // TikTok se coupe dès qu'il n'est plus affiché (cadre vidé, rechargé au retour) ; YouTube reste actif pour garder la musique
  for (const f of $('web').querySelectorAll('iframe')) {
    if ((view !== 'web' || f.hidden) && new URL(f.dataset.url).hostname.endsWith('tiktok.com')) f.src = 'about:blank'
  }
  $('readpage').hidden = true // réaffiché par showEmbedded pour une IA
  if (view !== 'web') try { localStorage.setItem('view', view) } catch {} // vue web : vide au rechargement
}

// boutons seulement : les sections portent aussi data-view, un clic dedans ramènerait sur leur vue
for (const b of document.querySelectorAll('button[data-view], button[data-go]')) {
  b.addEventListener('click', () => show(b.getAttribute('data-view') ?? b.getAttribute('data-go')))
}

// --- Accueil : horloge (les autres cartes sont remplies par chaque module)
function tick() {
  const d = new Date()
  $('time').textContent = d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
  $('date').textContent = d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })
}
tick()
setInterval(tick, 15_000)

// --- Raccourcis (sites ou fichiers locaux lancés par le programme local)
async function getShortcuts() {
  const { shortcuts } = await getSync({ shortcuts: [] })
  return shortcuts
}

async function renderShortcuts() {
  const list = await getShortcuts()
  $('shortcuts').replaceChildren(...list.map((s, i) => row(
    span('name', s.label),
    button('↗', s.target, () =>
      /^https?:/.test(s.target) ? chrome.tabs.create({ url: s.target }) : host({ action: 'launch', path: s.target })),
    button('✕', 'Supprimer', async () => {
      list.splice(i, 1)
      await chrome.storage.sync.set({ shortcuts: list })
      renderShortcuts()
    }),
  )))
}

$('add').onsubmit = async e => {
  e.preventDefault()
  const form = /** @type {HTMLFormElement} */ (e.target)
  const f = new FormData(form)
  const list = await getShortcuts()
  list.push({ label: String(f.get('label')).trim(), target: String(f.get('target')).trim() })
  await chrome.storage.sync.set({ shortcuts: list })
  form.reset()
  renderShortcuts()
}

// --- Apps web : dans le panneau si le site est dans EMBED_DOMAINS (embed.js), sinon fenêtre étroite collée à droite de Chrome
const DEFAULT_APPS = [
  { label: 'Gemini', url: 'https://gemini.google.com/app', icon: 'gemini', color: '#8E75B2' },
  { label: 'YouTube', url: 'https://www.youtube.com/', icon: 'youtube', color: '#FF0000' },
  { label: 'TikTok', url: 'https://www.tiktok.com/', icon: 'tiktok', color: 'var(--fg)' },
  { label: 'Discord', url: 'https://discord.com/app', icon: 'discord', color: '#5865F2' },
  { label: 'Perplexity', url: 'https://www.perplexity.ai/', icon: 'perplexity', color: '#1FB8CD' },
  { label: 'NotebookLM', url: 'https://notebooklm.google.com/', icon: 'notebooklm', color: '#4285F4' },
  { // la page Google de choix du compte refuse les cadres (403) : changement de compte par l'avatar dans Drive,
    // première connexion par « ↗ Onglet » ; barre d'outils au-dessus de Drive
    label: 'Drive', icon: 'googledrive', color: '#4285F4', url: 'https://drive.google.com/drive/my-drive',
    tools: [
      { label: 'Mon Drive', url: 'https://drive.google.com/drive/my-drive' },
      { label: '＋ Doc', url: 'https://docs.google.com/document/create' },
      { label: '＋ Sheet', url: 'https://docs.google.com/spreadsheets/create' },
      { label: '＋ Slides', url: 'https://docs.google.com/presentation/create' },
      { label: '＋ Form', url: 'https://docs.google.com/forms/create' },
      { label: '↗ Onglet', url: 'https://drive.google.com/drive/my-drive', tab: true },
    ],
  },
]
const WHATSAPP = { label: 'WhatsApp', url: 'https://web.whatsapp.com/' }
const DOCK_WIDTH = 480

// Twitch est toujours proposé (ajouté à la lecture, pas enregistré) : les listes d'apps déjà enregistrées n'ont pas à être migrées
const TWITCH = { label: 'Twitch', url: 'https://www.twitch.tv/', icon: 'twitch', color: '#9146FF' }

// la page de connexion Google refuse les cadres : « Se connecter » l'ouvre dans un onglet (une fois), puis la boîte marche dans le panneau
const GMAIL_URL = 'https://mail.google.com/mail/u/0/'
const GMAIL = {
  label: 'Gmail', url: GMAIL_URL, icon: 'gmail', color: '#EA4335',
  tools: [
    { label: 'Boîte de réception', url: GMAIL_URL },
    { label: '🔑 Se connecter', url: 'https://accounts.google.com/ServiceLogin?service=mail&continue=' + encodeURIComponent(GMAIL_URL), tab: true },
    { label: '↗ Onglet', url: GMAIL_URL, tab: true },
  ],
}

async function getApps() {
  const { webapps } = await getSync({ webapps: DEFAULT_APPS })
  return [...webapps, ...[TWITCH, GMAIL].filter(x => !webapps.some(a => a.url === x.url))]
}

async function openDocked(app) {
  const { docked = {} } = /** @type {any} */ (await chrome.storage.session.get('docked'))
  if (docked[app.url]) {
    try { return await chrome.windows.update(docked[app.url], { focused: true }) } catch { /* fenêtre fermée entre-temps */ }
  }
  const win = await chrome.windows.getCurrent()
  const w = await chrome.windows.create({
    url: app.url, type: 'popup', width: DOCK_WIDTH, height: win.height, top: win.top, left: win.left + win.width,
  })
  docked[app.url] = w.id
  await chrome.storage.session.set({ docked })
}

const embeddable = url => {
  const h = new URL(url).hostname
  return EMBED_DOMAINS.some(d => h === d || h.endsWith('.' + d))
}

// Un cadre par app, créé au 1er clic puis gardé (session, lecture en cours…) ; seul celui de l'app choisie est visible
function showEmbedded(app, btn) {
  const frames = [...$('web').querySelectorAll('iframe')]
  let f = frames.find(f => f.dataset.url === app.url)
  if (f && (btn.classList.contains('on') || f.src === 'about:blank')) f.src = app.url // 2e clic sur l'app affichée : recharge (cadre planté ou vidéo figée) ; ou réveil après pause
  if (!f) {
    f = document.createElement('iframe')
    f.dataset.url = app.url
    f.src = app.url
    f.allow = 'autoplay; fullscreen; clipboard-read; clipboard-write; microphone; camera'
    // Perplexity (comme son extension officielle) : sandbox sans allow-top-navigation, sinon son script sort du cadre (« n'autorise pas la connexion »)
    if (new URL(app.url).hostname.endsWith('perplexity.ai')) f.setAttribute('sandbox', 'allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation')
    $('web').append(f)
  }
  for (const g of $('web').querySelectorAll('iframe')) g.hidden = g !== f
  // outils de l'app (Drive : créer un fichier, ouvrir en grand) ; liens fixes, jamais lus depuis la page
  $('appbar').classList.remove('tw')
  $('web').classList.remove('twmode') // remis par renderTwitchBar : pour Twitch seule la liste est visible
  $('appbar').hidden = !app.tools
  $('appbar').replaceChildren(...(app.tools ?? []).map(t =>
    button(t.label, t.url, () => { if (t.tab) chrome.tabs.create({ url: t.url }); else f.src = t.url })))
  show('web')
  if (app.url === TWITCH.url) renderTwitchBar()
  btn.classList.add('on')
  $('readpage').hidden = !AI_HOSTS.some(h => new URL(app.url).hostname.endsWith(h))
}

// --- Twitch : seulement la liste des chaînes suivies, en ligne puis hors ligne. Le cadre Twitch reste chargé (c'est lui qui
// fournit la liste, lue par tw.js) mais il est caché derrière la liste ; un clic sur une chaîne l'ouvre dans un onglet.
let twChannels = []
let twPage = false // « Afficher Twitch » : la page elle-même, pour se connecter
try { getLocal('tw').then(r => { twChannels = r.tw ?? []; renderTwitchBar() }) } catch {}

function twRow(c) {
  const li = row()
  li.className = 'twrow' + (c.live ? '' : ' off')
  li.tabIndex = 0
  const open = () => chrome.tabs.create({ url: `https://www.twitch.tv/${c.login}` })
  li.onclick = open
  li.onkeydown = e => { if (e.key === 'Enter') open() }
  if (c.avatar) {
    const img = document.createElement('img')
    img.src = c.avatar
    img.alt = ''
    li.append(img)
  }
  li.append(span('name', c.name), span('pct', c.live ? '🔴 en ligne' : 'hors ligne'))
  return li
}

function renderTwitchBar() {
  const f = [...$('web').querySelectorAll('iframe')].find(f => f.dataset.url === TWITCH.url)
  if (!f || f.hidden) return
  const live = twChannels.filter(c => c.live).length
  publish('tw', live)
  const bar = $('appbar')
  bar.classList.add('tw')
  bar.hidden = false
  const head = document.createElement('div')
  head.className = 'twhead'
  head.append(span('name', `${live} en ligne · ${twChannels.length} suivie(s)`),
    button(twPage ? 'Liste' : 'Afficher Twitch', 'Basculer entre la liste et la page Twitch (pour te connecter)', () => { twPage = !twPage; renderTwitchBar() }))
  $('web').classList.toggle('twmode', !twPage)
  const ul = document.createElement('ul')
  ul.className = 'twlist'
  ul.hidden = twPage
  ul.append(...(twChannels.length ? [...twChannels].sort((a, b) => b.live - a.live || a.name.localeCompare(b.name)).map(twRow)
    : [row(span('muted', 'Aucune chaîne : clique sur « Afficher Twitch » pour te connecter, puis sur « Liste ».'))]))
  bar.replaceChildren(head, ul)
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg?.type !== 'tw' || !Array.isArray(msg.channels)) return
  twChannels = msg.channels.slice(0, 200).filter(c => /^[A-Za-z0-9_]{1,25}$/.test(c?.login)).map(c => ({
    login: c.login, name: String(c.name ?? c.login).slice(0, 40), live: !!c.live,
    avatar: String(c.avatar ?? '').startsWith('https://static-cdn.jtvnw.net/') ? c.avatar : '' }))
  chrome.storage.local.set({ tw: twChannels })
  publish('tw', twChannels.filter(c => c.live).length)
  renderTwitchBar()
})

// --- Lire la page pour une IA du panneau : copiée dans le presse-papiers, collée par l'utilisateur (rien n'est envoyé seul)
const AI_HOSTS = ['gemini.google.com', 'perplexity.ai', 'notebooklm.google.com', 'notebook.google.com', 'chatgpt.com', 'claude.ai']
const READ_MAX = 20000 // caractères de page copiés au plus

let toastTimer
function toast(text) {
  $('toast').textContent = text
  $('toast').hidden = false
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { $('toast').hidden = true }, 4000)
}

// Sélection s'il y en a une, sinon le texte visible de la page ; titre et adresse seuls sur une page protégée
async function readActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true })
  let sel = '', body = ''
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { const s = String(getSelection()).trim(); return { s, b: s ? '' : document.body?.innerText ?? '' } },
    })
    sel = result.s
    body = result.b
  } catch { /* chrome://, Web Store, PDF */ }
  const text = sel ? `Sélection :\n${sel}` : body ? `Contenu de la page :\n${body}` : ''
  const cut = text.length > READ_MAX
  return { full: `Page : ${tab.title}\nAdresse : ${tab.url}\n\n${text.slice(0, READ_MAX)}${cut ? '\n[…coupé]' : ''}`, sel, body, cut }
}

$('readpage').onclick = async () => {
  try {
    const r = await readActiveTab()
    await navigator.clipboard.writeText(r.full)
    toast((r.sel ? 'Sélection copiée' : r.body ? 'Page copiée' : 'Titre et adresse copiés (page illisible)')
      + (r.cut ? ' (coupée à 20 000 car.)' : '') + ' : clique dans la zone de l\'IA puis Ctrl+V.')
    $('web').querySelector('iframe:not([hidden])')?.focus()
  } catch (e) { showError(e) }
}

function appIcon(app) {
  if (app.icon) {
    const i = document.createElement('i')
    i.style.setProperty('--i', `url(icons/${app.icon}.svg)`)
    i.style.setProperty('--c', app.color)
    return i
  }
  const img = document.createElement('img') // app ajoutée : favicon fourni par Chrome, sans requête externe
  img.src = chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(app.url)}&size=32`)
  img.alt = ''
  return img
}

async function renderApps() {
  const apps = await getApps()
  $('apps').replaceChildren(...apps.map(app => {
    const b = document.createElement('button')
    b.title = app.label
    b.dataset.url = app.url // lu par rail.js (badge Twitch)
    b.append(appIcon(app))
    b.onclick = () => embeddable(app.url) ? showEmbedded(app, b) : openDocked(app).catch(showError)
    return b
  }))
  $('applist').replaceChildren(...apps.map((app, i) => row(
    span('name', app.label),
    button('✕', 'Retirer', async () => {
      apps.splice(i, 1)
      await chrome.storage.sync.set({ webapps: apps })
      renderApps()
    }),
  )))
}

$('addapp').onsubmit = async e => {
  e.preventDefault()
  const form = /** @type {HTMLFormElement} */ (e.target)
  const f = new FormData(form)
  const url = String(f.get('url')).trim()
  if (!/^https:\/\//i.test(url)) return showError('Adresse https:// uniquement')
  const apps = await getApps()
  apps.push({ label: String(f.get('label')).trim(), url })
  await chrome.storage.sync.set({ webapps: apps })
  form.reset()
  renderApps()
}

$('open-wa').onclick = () => showEmbedded(WHATSAPP, document.createElement('button'))

// Nombre de discussions non lues, envoyé par wa.js (WhatsApp dans le panneau ou dans un onglet) ; null tant que WhatsApp n'a rien envoyé
let waCount = null
function renderWa() {
  $('wamsg').textContent = waCount == null ? 'Ouvre WhatsApp : le compteur apparaît une fois la page chargée.'
    : waCount ? `${waCount} discussion(s) non lue(s)` : 'Aucune discussion non lue'
  $('home-wacount').textContent = waCount ? `WhatsApp ${waCount}` : ''
  publish('wa', waCount)
}
chrome.runtime.onMessage.addListener(msg => {
 if (msg?.type === 'wa' && Number.isFinite(msg.n)) { waCount = msg.n; renderWa() } })

// --- Notes : sur ce PC seulement (storage.local), enregistrées pendant la frappe
let notes = [] // [{id, title, text, at, pinned}]
let noteId = null
let noteTimer

const noteTitle = n => n.title.trim() || n.text.trim().split('\n')[0].slice(0, 60) || 'Note vide'
const sortedNotes = () => [...notes].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.at - a.at)

function saveNotes() {
  clearTimeout(noteTimer)
  noteTimer = setTimeout(() => chrome.storage.local.set({ notes }).catch(showError), 400)
}

function renderNotes() {
  const cur = notes.find(n => n.id === noteId)
  $('notelist').replaceChildren(...sortedNotes().map(n => {
    const li = row(span('name', (n.pinned ? '📌 ' : '') + noteTitle(n)), span('pct', when(n.at)))
    li.classList.toggle('on', n.id === noteId)
    li.onclick = () => openNote(n.id)
    return li
  }))
  if (!notes.length) $('notelist').replaceChildren(row(span('muted', 'Aucune note : ＋ pour en créer une.')))
  const top = sortedNotes().slice(0, 3)
  $('home-notes').replaceChildren(...(top.length ? top.map(n => {
    const li = row(span('name', (n.pinned ? '📌 ' : '') + noteTitle(n)))
    li.onclick = () => openNote(n.id)
    return li
  }) : [row(span('muted', 'Aucune note'))]))
  $('note-edit').hidden = !cur
  if (cur) $('note-pin').textContent = cur.pinned ? '📌 Désépingler' : '📌 Épingler'
}

function openNote(id) {
  noteId = id
  const n = notes.find(n => n.id === id)
  $('note-title').value = n.title
  $('note-text').value = n.text
  $('note-del').textContent = '✕ Supprimer'
  show('notes')
  renderNotes()
  $('note-text').focus()
}

function editNote(field, value) {
  const n = notes.find(n => n.id === noteId)
  if (!n) return
  n[field] = value
  n.at = Date.now()
  saveNotes()
  renderNotes()
}

$('note-new').onclick = () => {
  notes.push({ id: crypto.randomUUID(), title: '', text: '', at: Date.now(), pinned: false })
  saveNotes()
  openNote(notes[notes.length - 1].id)
}
$('note-title').oninput = () => editNote('title', $('note-title').value)
$('note-text').oninput = () => editNote('text', $('note-text').value)
$('note-pin').onclick = () => editNote('pinned', !notes.find(n => n.id === noteId)?.pinned)
$('note-del').onclick = () => { // 2 clics : pas de fenêtre de confirmation
  if ($('note-del').textContent !== 'Confirmer ?') { $('note-del').textContent = 'Confirmer ?'; return }
  notes = notes.filter(n => n.id !== noteId)
  noteId = null
  saveNotes()
  renderNotes()
}

async function loadNotes() {
  notes = (await getLocal({ notes: [] })).notes
  renderNotes()
}

// --- Builds Diablo IV : "Mes Builds" envoyés par le userscript Diablo IV Assistant 3.68+ (background.js), carte de l'accueil
const D4_SITUATIONS = { leveling: 'Montée de niveau', endgame: 'Endgame', farm: 'Farm de matériaux' }

async function renderD4() {
  const { d4 } = await getLocal('d4')
  const who = [d4?.author, D4_SITUATIONS[d4?.situation]].filter(Boolean).join(' · ')
  const builds = (d4?.builds ?? []).map(b => row(link(b.title, b.url), span('pct', `${b.classLabel} · ${b.source}`)))
  $('home-d4').replaceChildren(...(who ? [row(span('muted', who))] : []),
    ...(builds.length ? builds : [row(span('muted', d4 ? 'Aucun build sauvegardé' : 'Pas encore de données : ouvre un site de build avec Diablo IV Assistant'))]))
}

// --- Vidéo Continuum : dernier envoi du userscript 7.5+ (background.js), carte « À rattraper » de l'accueil
// Le libellé d'épisode répète souvent le nom de la série : on ne garde que la fin (« Spéciaux E04 »)
const shortEp = e => (e.episode.startsWith(e.name) ? e.episode.slice(e.name.length).trim() : '') || e.episode

async function renderVc() {
  const { vc } = await getLocal('vc')
  publish('vc', vc ? vc.behind.length : null)
  $('home-vc').replaceChildren(...(!vc ? [row(span('muted', 'Pas encore de données'))] : vc.behind.length ? vc.behind.map(e => row(
    link(e.name, e.url),
    span('pct', `${shortEp(e)}${e.latest ? ' / ' + e.latest : ''} · ${e.site}`),
  )) : [row(span('muted', 'Tout est à jour'))]))
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.vc) renderVc()
  if (area === 'local' && changes.d4) renderD4()
  if (area === 'sync' && changes.webapps) renderApps()
})

async function init() {
}

ready = init()
try { show(localStorage.getItem('view') || 'home') } catch { show('home') }
renderApps()
renderShortcuts()
renderVc()
renderD4()
loadNotes()
renderWa()

// Rail à gauche (défaut) ou à droite, choix gardé sur cet appareil
getLocal({ railRight: false }).then(({ railRight }) => document.body.classList.toggle('rail-right', railRight))
$('railside').onclick = () => {
  const right = document.body.classList.toggle('rail-right')
  chrome.storage.local.set({ railRight: right })
}
