// Sites que SideBar affiche dans son panneau (en-têtes anti-cadre retirés hors onglet, voir background.js).
// Partagé par background.js (importScripts) et panel.js (balise script).
const EMBED_DOMAINS = [
  'gemini.google.com', 'accounts.google.com', 'youtube.com', 'tiktok.com', 'discord.com', 'chatgpt.com', 'auth.openai.com', 'perplexity.ai', 'notebooklm.google.com', 'notebook.google.com', 'whatsapp.com', 'twitch.tv',
  'mail.google.com', 'drive.google.com', 'docs.google.com', 'drive.usercontent.google.com', 'googleusercontent.com',
]
