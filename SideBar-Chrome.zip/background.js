chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }) // absent dans Opera (panneau par sidebar_action)

// Apps web affichées DANS le panneau (choix de l'utilisateur le 2026-10-18, comme SideApps) : leurs en-têtes anti-cadre
// sont retirés, mais seulement pour ces sites et seulement hors onglet (tabId -1 = cadres du panneau latéral) ;
// les onglets normaux gardent toutes leurs protections. Règles de session : remises à chaque réveil du service worker.
importScripts('embed.js')
// scope : Chrome = cadres du panneau (onglet -1) ; Opera = requêtes lancées par une page de l'extension (panneau de sidebar_action ou fenêtre), dont l'onglet n'est pas -1
const setRules = scope => chrome.declarativeNetRequest.updateSessionRules({
  removeRuleIds: [1, 2],
  addRules: [{
    // Drive / Docs (403) et WhatsApp Web (400, « Sorry, something went wrong ») refusent une requête de cadre : présentée comme une page, toujours seulement dans le panneau
    id: 2,
    action: { type: 'modifyHeaders', requestHeaders: [{ header: 'sec-fetch-dest', operation: 'set', value: 'document' }] },
    condition: { requestDomains: ['drive.google.com', 'docs.google.com', 'mail.google.com', 'whatsapp.com'], ...scope, resourceTypes: ['sub_frame'] },
  }, {
    id: 1,
    action: {
      type: 'modifyHeaders',
      responseHeaders: [
        { header: 'x-frame-options', operation: 'remove' },
        { header: 'content-security-policy', operation: 'remove' }, // porte frame-ancestors (TikTok, Discord…)
      ],
    },
    condition: { requestDomains: EMBED_DOMAINS, ...scope, resourceTypes: ['sub_frame'] },
  }],
})
setRules(chrome.sidePanel ? { tabIds: [chrome.tabs.TAB_ID_NONE] } : { initiatorDomains: [chrome.runtime.id] })

// Opera : pas de chrome.sidePanel et sidebar_action non pris en charge pour une extension chargée à la main -> clic sur l'icône =
// fenêtre étroite à droite montrant le panneau ; ses cadres portent l'identifiant de l'onglet de cette fenêtre (pas -1), qui reçoit les mêmes règles.
if (!chrome.sidePanel) {
  const WIDTH = 480
  // fenêtre maximisée : left/top/width/height donnés par Opera sont ceux de l'écran de travail
  const maxBounds = async w => ({ left: w.left, top: w.top, width: w.width, height: w.height })
  const open = async () => {
    const { win } = await chrome.storage.session.get('win')
    if (win) { try { return await chrome.windows.update(win, { focused: true }) } catch { /* fermée */ } }
    // SideBar collée à gauche ; Opera est rétréci pour ne rien cacher, et remis comme avant à la fermeture de SideBar
    const cur = await chrome.windows.getLastFocused()
    const b = cur.state === 'maximized' ? await maxBounds(cur) : cur
    await chrome.windows.update(cur.id, { state: 'normal', left: b.left + WIDTH, top: b.top, width: b.width - WIDTH, height: b.height })
    const w = await chrome.windows.create({ url: 'panel.html', type: 'popup', width: WIDTH, height: b.height, top: b.top, left: b.left })
    await chrome.storage.session.set({ win: w.id, opera: { id: cur.id, state: cur.state, left: cur.left, top: cur.top, width: cur.width, height: cur.height } })
  }
  chrome.action.onClicked.addListener(() => open().catch(console.error))
  chrome.windows.onRemoved.addListener(id => chrome.storage.session.get(['win', 'opera']).then(async ({ win, opera }) => {
    if (win !== id) return
    await chrome.storage.session.remove(['win', 'opera'])
    if (!opera) return
    try { await chrome.windows.update(opera.id, opera.state === 'maximized' ? { state: 'maximized' } : { left: opera.left, top: opera.top, width: opera.width, height: opera.height }) } catch { /* Opera fermé */ }
  }))
}

// Vidéo Continuum (userscript 7.5+) envoie les épisodes à rattraper et ses sites après chaque vérification.
// Donnée venue d'une page : seuls les champs attendus sont gardés, liens https uniquement.
const https = u => (typeof u === 'string' && u.length <= 2000 && /^https:\/\//i.test(u) ? u : null)
const objs = a => (Array.isArray(a) ? a : []).filter(e => e && typeof e === 'object') // entrées non-objets (null, nombres…) ignorées
const STORE_MAX = 1_000_000 // car. sérialisés au plus par envoi (quota storage.local : 10 Mo)
// Écrit si la taille reste raisonnable ; répond toujours (même en cas d'échec), sans jamais lever
function save(key, value, reply) {
  if (JSON.stringify(value).length > STORE_MAX) return reply({ ok: false, error: 'trop gros' })
  chrome.storage.local.set({ [key]: value }).then(() => reply({ ok: true }), () => reply({ ok: false, error: 'stockage' }))
  return true // réponse asynchrone
}
const str = v => (v == null ? '' : String(v).slice(0, 300))
chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  // Diablo IV Assistant (userscript 3.67+) : "Mes Builds", un favori par classe
  if (msg?.type === 'd4builds' && Array.isArray(msg.builds)) {
    return save('d4', {
        at: Date.now(),
        author: str(msg.author), // 3.68+ : pseudo et situation de « Créer mon filtre »
        situation: ['leveling', 'endgame', 'farm'].includes(msg.situation) ? msg.situation : '',
        builds: objs(msg.builds).slice(0, 20).map(b => ({ classLabel: str(b.classLabel), title: str(b.title), source: str(b.source), url: https(b.url) })),
    }, reply)
  }
  if (msg?.type !== 'vc' || !Array.isArray(msg.behind) || !Array.isArray(msg.sites)) return
  return save('vc', {
    at: Date.now(),
    from: sender.origin,
    behind: objs(msg.behind).slice(0, 500).map(e => ({ name: str(e.name), episode: str(e.episode), latest: str(e.latest), site: str(e.site), url: https(e.url) })),
    checkedAt: Number.isFinite(msg.checkedAt) ? msg.checkedAt : null,
    // 7.6+ : séries suivies (toutes) et historique, absents des versions précédentes
    series: objs(msg.series).slice(0, 500).map(e => ({
      name: str(e.name), site: str(e.site), tag: str(e.tag), ep: str(e.ep), url: https(e.url), at: str(e.at),
      latest: str(e.latest), next: https(e.next), behind: !!e.behind })),
    history: objs(msg.history).slice(0, 50).map(e => ({
      name: str(e.name), site: str(e.site), ep: str(e.ep), url: https(e.url), at: str(e.at) })),
    sites: objs(msg.sites).slice(0, 100).map(s => ({ label: str(s.label), url: https(s.url) })).filter(s => s.url),
  }, reply)
})
