// Globales chargées par extension/vendor (xterm.js et son addon, scripts UMD) : pas de types installés
declare const Terminal: any
declare const FitAddon: any
// Service worker (background.js) : importScripts existe là, absent de la lib DOM
declare function importScripts(...urls: string[]): void
