// Injecté dans Twitch quand la page est affichée DANS le panneau SideBar (cadre), jamais dans un onglet normal :
// masque la liste de gauche de Twitch (SideBar affiche la sienne au-dessus du cadre) et lui envoie les chaînes suivies lues
// dans cette liste (section « Chaînes suivies »). Rien d'autre n'est lu.
if (window !== window.top) {
  const style = document.createElement('style')
  style.textContent = '#side-nav, [data-test-selector="side-nav"], .side-nav { display: none !important }'
  document.documentElement.append(style)

  // Largeur du panneau : Twitch réduit sa liste (avatars seulement, ni jeu ni spectateurs) ; une carte sans avatar « --offline »
  // est en direct. Le nom est celui de l'adresse (l'alt des images contient le texte d'une infobulle).
  const collect = () => {
    const section = [...document.querySelectorAll('.side-nav-section[aria-label]')].find(s => /suivi|followed|following/i.test(s.getAttribute('aria-label')))
    const out = []
    for (const a of section?.querySelectorAll('a.side-nav-card') ?? []) {
      const login = a.getAttribute('href')?.match(/^\/([A-Za-z0-9_]{1,25})$/)?.[1]
      if (!login) continue
      const avatar = [...a.querySelectorAll('img')].map(i => i.src).find(s => s.startsWith('https://static-cdn.jtvnw.net/')) ?? ''
      out.push({ login, name: login, live: !a.querySelector('.side-nav-card__avatar--offline'), avatar })
    }
    return out
  }

  let last = ''
  const send = () => {
    const channels = collect()
    const key = JSON.stringify(channels)
    if (!channels.length || key === last) return
    last = key
    chrome.runtime.sendMessage({ type: 'tw', channels }).catch(() => {})
  }
  // pas d'observateur de mutations : le chat de Twitch change sans cesse ; on relit au chargement puis toutes les 30 s
  setTimeout(send, 4000)
  setTimeout(send, 10_000)
  setInterval(send, 30_000)
}
