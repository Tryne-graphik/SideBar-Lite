// Rail : accessibilité (toolbar, noms, tabulation « roving »), info-bulles immédiates,
// badges de l'état publié par panel.js et raccourcis clavier. Fichier de l'agent "rail" (nuit).
// Chargé AVANT panel.js : on attend DOMContentLoaded et on observe #apps (boutons créés après coup).
(() => {
  const BASE = new WeakMap() // libellé d'origine d'un bouton (sans le nombre du badge)
  const SEEN = new WeakSet()
  let nav = null
  let tip = null
  let state = {}
  let ready = false
  let roving = null
  let hoverBtn = null // bouton sous la souris
  let focusBtn = null // bouton qui a le focus clavier

  const allButtons = () => nav ? [...nav.querySelectorAll('button')] : []
  // Même définition que le test d'acceptation : bouton présent et réellement affiché
  const visibleButtons = () => allButtons().filter(b => !b.hidden && b.offsetParent)

  function baseLabel(b) {
    if (!BASE.has(b)) {
      const label = (b.getAttribute('aria-label') || b.title || b.textContent || '').trim() || 'Bouton'
      BASE.set(b, label)
    }
    return BASE.get(b)
  }

  // aria-label repris du title (puis title retiré : l'info-bulle immédiate le remplace)
  function prepare(b) {
    if (SEEN.has(b)) return
    SEEN.add(b)
    const label = baseLabel(b)
    b.removeAttribute('title')
    b.setAttribute('aria-label', label)
    b.tabIndex = b === roving ? 0 : -1
  }

  function setRoving(b) {
    roving = b
    for (const x of allButtons()) x.tabIndex = x === b ? 0 : -1
  }

  // aria-current suit l'onglet actif (classe on posée par show() de panel.js)
  function updateCurrent() {
    for (const b of allButtons()) {
      if (b.classList.contains('on')) b.setAttribute('aria-current', 'page')
      else b.removeAttribute('aria-current')
    }
  }

  const count = value => {
    const n = Number(value)
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0
  }

  // Ne réécrit que si le texte change : l'observateur du rail écoute aussi childList,
  // une écriture identique à chaque passage boucherait la boucle (microtâches sans fin).
  function setBadge(b, n, suffix) {
    if (!b) return
    let badge = b.querySelector('.badge')
    const label = n ? `${baseLabel(b)}, ${n} ${suffix(n)}` : baseLabel(b)
    if (b.getAttribute('aria-label') !== label) b.setAttribute('aria-label', label)
    if (!n) {
      if (badge) badge.remove()
      return
    }
    if (!badge) {
      badge = document.createElement('span')
      badge.className = 'badge'
      badge.setAttribute('aria-hidden', 'true') // le nombre est déjà dans l'aria-label du bouton
      b.append(badge)
    }
    const text = n > 99 ? '99+' : String(n)
    if (badge.textContent !== text) badge.textContent = text
  }

  // Badges : Mails, WhatsApp, séries à rattraper (Accueil), chaînes Twitch en ligne
  function applyBadges() {
    if (!nav) return
    setBadge(nav.querySelector('[data-view="email"]'), count(state.mail), n => n > 1 ? 'non lus' : 'non lu')
    setBadge(nav.querySelector('[data-view="msg"]'), count(state.wa), n => n > 1 ? 'discussions non lues' : 'discussion non lue')
    setBadge(nav.querySelector('[data-view="home"]'), count(state.vc), n => n > 1 ? 'séries à rattraper' : 'série à rattraper')
    setBadge(nav.querySelector('#apps button[data-url*="twitch.tv"]'), count(state.tw), n => n > 1 ? 'chaînes en ligne' : 'chaîne en ligne')
  }

  function showTip(b) {
    if (!ready || !tip) return
    const label = b.getAttribute('aria-label') || baseLabel(b)
    if (!label) return
    tip.textContent = label
    tip.classList.add('on')
    // Mesure sans scintillement, puis placement à gauche du bouton (à droite s'il n'y a pas la place)
    tip.style.visibility = 'hidden'
    const r = b.getBoundingClientRect()
    const w = tip.offsetWidth
    const h = tip.offsetHeight
    let left = r.right + 8 // rail à gauche : info-bulle à droite du bouton
    if (left + w > window.innerWidth - 4) left = Math.max(4, r.left - w - 8)
    let top = r.top + (r.height - h) / 2
    top = Math.max(4, Math.min(top, window.innerHeight - h - 4))
    tip.style.left = `${Math.round(left + window.scrollX)}px`
    tip.style.top = `${Math.round(top + window.scrollY)}px`
    tip.style.visibility = ''
  }

  function hideTip() {
    if (tip) tip.classList.remove('on')
  }

  // La souris peut rester posée sur un bouton quand le focus part ailleurs (ou l'inverse) :
  // on garde l'info-bulle du bouton encore survolé, sinon celle du bouton qui a le focus.
  function refreshTip() {
    const b = focusBtn || hoverBtn
    if (b) showTip(b)
    else hideTip()
  }

  const buttonOf = target => {
    const b = target instanceof Element ? target.closest('button') : null
    return b && nav.contains(b) ? b : null
  }

  function onKey(e) {
    if (e.altKey || e.ctrlKey || e.metaKey) return
    const list = visibleButtons()
    if (!list.length) return
    const i = list.indexOf(document.activeElement)
    let next = -1
    if (e.key === 'ArrowDown') next = i < 0 ? 0 : Math.min(i + 1, list.length - 1)
    else if (e.key === 'ArrowUp') next = i < 0 ? 0 : Math.max(i - 1, 0)
    else if (e.key === 'Home') next = 0
    else if (e.key === 'End') next = list.length - 1
    if (next < 0) return
    e.preventDefault()
    list[next].focus()
  }

  // Alt+1..9 : active le n-ième bouton visible du rail (sauf pendant une saisie de texte)
  function onAltDigit(e) {
    if (!e.altKey || e.ctrlKey || e.metaKey) return
    const t = e.target
    if (t instanceof Element && t.closest('input, textarea, select, [contenteditable="true"]')) return
    const m = /^(?:Digit|Numpad)([1-9])$/.exec(e.code)
    if (!m) return
    const b = visibleButtons()[Number(m[1]) - 1]
    if (!b) return
    e.preventDefault()
    b.click()
    b.focus()
  }

  function init() {
    nav = document.getElementById('rail')
    if (!nav) return
    nav.setAttribute('role', 'toolbar')
    nav.setAttribute('aria-orientation', 'vertical')
    nav.setAttribute('aria-label', 'Barre de navigation')
    // L'événement a pu partir avant notre chargement : on garde ce qui a déjà été reçu
    state = { ...state, ...(/** @type {any} */ (window).sbState || {}) }

    tip = document.createElement('div')
    tip.className = 'rail-tip'
    tip.setAttribute('role', 'tooltip')
    document.body.append(tip)

    for (const b of allButtons()) prepare(b)
    setRoving(nav.querySelector('button.on') || visibleButtons()[0] || allButtons()[0])

    const reload = document.getElementById('reload')
    if (reload) reload.classList.add('dev')

    updateCurrent()
    applyBadges()
    ready = true

    // Boutons d'apps créés après coup, classe on, boutons masqués : tout est réévalué
    new MutationObserver(() => {
      for (const b of allButtons()) prepare(b)
      // un bouton d'app retiré/recréé peut emporter le bouton « roving » : on en choisit un autre
      if (!roving || !roving.isConnected || roving.hidden) {
        setRoving(nav.querySelector('button.on') || visibleButtons()[0] || allButtons()[0])
      }
      updateCurrent()
      applyBadges()
      // Le bouton survolé ou focalisé a pu disparaître (apps réaffichées) : pas d'info-bulle fantôme
      if (hoverBtn && !hoverBtn.isConnected) hoverBtn = null
      if (focusBtn && (!focusBtn.isConnected || focusBtn.hidden)) focusBtn = null
      refreshTip()
    }).observe(nav, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden', 'data-url'] })

    nav.addEventListener('keydown', onKey)
    // Le rail défile (fenêtre basse) ou la fenêtre change de taille : replacer l'info-bulle
    const replaceTip = () => { if (tip && tip.classList.contains('on')) refreshTip() }
    nav.addEventListener('scroll', replaceTip)
    window.addEventListener('resize', replaceTip)
    window.addEventListener('scroll', replaceTip, { passive: true })
    nav.addEventListener('mouseover', e => {
      const b = buttonOf(e.target)
      if (!b) return
      hoverBtn = b
      refreshTip()
    })
    nav.addEventListener('mouseout', e => {
      if (buttonOf(e.relatedTarget)) return // on reste sur un bouton du rail
      hoverBtn = null
      refreshTip()
    })
    nav.addEventListener('focusin', e => {
      const b = buttonOf(e.target)
      if (!b) return
      focusBtn = b
      setRoving(b)
      refreshTip()
    })
    nav.addEventListener('focusout', e => {
      if (buttonOf(e.relatedTarget)) return
      focusBtn = null
      refreshTip()
    })
    document.addEventListener('keydown', onAltDigit)
  }

  // État publié par panel.js à chaque changement (nombre, ou null si pas encore de données)
  document.addEventListener('sbstate', e => {
    state = (e instanceof CustomEvent ? e.detail : null) || {}
    if (ready) applyBadges()
  })

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init)
  else init()
})()
